$(function () {
    $.fn.serializeObject = function(){
      var o = {};
      var a = this.serializeArray();
      $.each(a, function() {
        if (o[this.name] !== undefined) {
          if (!o[this.name].push) {
            o[this.name] = [o[this.name]];
          }
          o[this.name].push(this.value || '');
        } else {
          o[this.name] = this.value || '';
        }
      });
      return o;
    };
});

//Map module
let mapModule = (function ($, window) {

	let _domAssets = {};
	let _assets = {};
	let _autocompletes = {};

	function _init(){
		_cacheDom();
		_assets.map = new google.maps.Map(_domAssets.$map.get(0), {
			"center": new google.maps.LatLng(41, -91),
			"zoom": 4
		});
		_assets.placesService = new google.maps.places.PlacesService(_assets.map);
 		_assets.directionsService = new google.maps.DirectionsService();
        _assets.directionsRenderer = new google.maps.DirectionsRenderer({"draggable": true});
        _assets.directionsRenderer.setMap(_assets.map);	

        _assets.directionsRenderer.addListener('directions_changed', function(){
        	_directionsChangedAction();
        });
	}

	function _directionsChangedAction(){
		if(typeof _assets.directionsRenderer.getDirections() == "undefined" || typeof _autocompletes.origin.getPlace() == "undefined" || typeof _autocompletes.destination.getPlace() == "undefined"){
			console.clear();
			console.log("Not all components are present");
			return false;
		}    	
    	let selectedRouteObject = _assets.directionsRenderer.getDirections();
    	console.log(selectedRouteObject);
    	let waypts = [];
    	if(selectedRouteObject.routes[0].legs[0].via_waypoints.length > 0){
    		for(i=0;i<selectedRouteObject.routes[0].legs[0].via_waypoints.length;i++){
    			waypts.push(selectedRouteObject.routes[0].legs[0].via_waypoints[i].toUrlValue().split(",").join(" "));
    		}
    	}

    	//Fire the request to see ZIP codes within buffer
    	ajaxModule.post(
    		{"line": _directionsPathToWKT(selectedRouteObject.routes[0].overview_path), "width": 25}, 
    		'zipbuffer',
    		function(data){
    			let rtAttribs = {
					"ac-origin": selectedRouteObject.routes[0].legs[0].start_address, 
					"ac-origin-ll": selectedRouteObject.routes[0].legs[0].start_location.toUrlValue(),
					"ac-destination": selectedRouteObject.routes[0].legs[0].end_address,
					"ac-destination-ll": selectedRouteObject.routes[0].legs[0].end_location.toUrlValue(),
					"waypts": (waypts.length > 0) ? waypts.join(",") : "",
					//"wkt": _directionsPathToWKT(selectedRouteObject.routes[0].overview_path)
				};
    			let routeData = $.extend(true, {}, {"zip_codes": data.cluster.routes[0].zip_codes.join(","), "wkt": data.cluster.routes[0].line}, rtAttribs)
    			controlModule.updateAddRouteForm(routeData);
    		});	
	}

	function _directionsPathToWKT(pathArray){
		let coordinates = [];
		for(i=0;i<pathArray.length;i++){
			coordinates.push(pathArray[i].toUrlValue().split(",").reverse().join(" "));
		}
		return ["LINESTRING(",coordinates.join(","),")"].join("");
	}

	function _initializeAutoComplete(elementJquery, name, ll_field){

		if(typeof name == "undefined"){
			let name = "default";
		}

		elementJquery
			.off()
			.on('click', function(){
				$(this).val('');
			});

		_autocompletes[name] = new google.maps.places.Autocomplete(elementJquery.get(0), {"types": ['geocode']});

        _autocompletes[name].setComponentRestrictions(
            {'country': ['us', 'ca']});

        // Specify only the data fields that are needed.
        _autocompletes[name].setFields(
            ['address_components', 'geometry', 'name', 'formatted_address']);

        _autocompletes[name].addListener('place_changed', function() {
        	let selectedPlace = this.getPlace();
        	document.getElementById(ll_field).value = selectedPlace.geometry.location.toUrlValue();
        	_grabDirections();
        });

	}

	function _grabDirections(){
		if(typeof _autocompletes.origin.getPlace() == "undefined" || typeof _autocompletes.destination.getPlace() == "undefined"){
			return false;
		}

        _assets.directionsService.route(
            {
              origin: {
              	"query": _autocompletes.origin.getPlace()["formatted_address"]},
              	"destination": {query: _autocompletes.destination.getPlace()["formatted_address"]},
              	"travelMode": "DRIVING"
            },
            function(response, status) {
              if (status === 'OK') {
              	console.log(response.geocoded_waypoints[0].place_id);
              	_assets.placesService.getDetails({placeId: response.geocoded_waypoints[0].place_id}, function(place, status){
              		if (status == google.maps.places.PlacesServiceStatus.OK) {
              			console.log(place);
              		}
              	});
                _assets.directionsRenderer.setDirections(response);
              } else {
                window.alert('Directions request failed due to ' + status);
              }
            });
	}

	function _cacheDom(){
		_domAssets.$map = $("#map");
	}
  	return {
  		initialize: _init,
  		addAutoComplete: _initializeAutoComplete,
  		directionsChangedAction: _directionsChangedAction
  	}

})($, window);

//Control module
let controlModule = (function ($, window) {
	
	let _domAssets = {};
	let _templates = {};

	function _init(){
		_cacheDom();

		//Load clusters into the cluster dropdown
		_loadClustersToList();
	}

	function _cacheDom(){
		_domAssets.controlMgmtArea = $("#control-mgmt-area");
		_domAssets.clusterDropDown = $("#cluster-dropdown-1");
		_domAssets.routeControls = $(".route-controls-1");
		_domAssets.routeDropdown = $("#routes-dropdown-1");

		_templates.addClusterUI = $("#m-tpl-cluster-add").html();
		_templates.addRouteUI = $("#m-tpl-route-add").html();
		_templates.updateRouteUI = $("#m-tpl-route-update").html();
		_templates.mainClusterListItems = $("#m-tpl-cluster-list-1").html();
		_templates.feedbackModal = $("#m-tpl-feedback").html();
		_templates.routesListItems = $("#m-tpl-route-list").html();

		_parseTemplates();
	}

	function _parseTemplates(){
		for(var prop in _templates){
			if (Object.prototype.hasOwnProperty.call(_templates, prop)) {
        		Mustache.parse(_templates[prop]);
    		}			
		}
	}
	function _addClusterUI(){
		_domAssets.controlMgmtArea
			.html('')
			.html(Mustache.render(_templates.addClusterUI, {}));

		$("#btn-cluster-add-cancel")
			.off()
			.on("click", function(){
				_domAssets.controlMgmtArea.html('');
			});	

		$("#btn-cluster-add-confirm")
			.off()	
			.on("click", function(){
				console.log("Confirmation clicked");
				ajaxModule.post({"clustername": $("#cl-name").val(), "truckid": $("#cl-truckid").val()}, 'clusters', function(data){
					console.log(data);
					_loadClustersToList();
					let $modal = $(Mustache.render(_templates.feedbackModal, data));
					_domAssets.controlMgmtArea.html('');
					$modal.modal("show");
					setTimeout(function(){						
						$modal.modal("hide");
					}, 2500);
				});
			});
	}
	function _loadClustersToList(){

		ajaxModule.get('clusters', function(data){
			if(data.status == "success"){				
				console.log("Loading selected cluster...");
				
				_domAssets.clusterDropDown
					.html(Mustache.render(_templates.mainClusterListItems,{"clusters": data.clusters}));			
				
				_domAssets.clusterDropDown
					.off()
					.on('change', function(){
						let selectedClusterID = $(this).val();
						_domAssets.routeControls.show();
						_loadRoutesListFromCluster(selectedClusterID);

						_domAssets.controlMgmtArea
							.html('');	

						$("#btn-route-add-cancel").on("click", function(){
							_domAssets.controlMgmtArea.html('');
						});						

						$("#btn-route-add-confirm").on("click", function(){

						});
					});				
			}
			else
			{
				//Failure
				_domAssets.controlMgmtArea.html('');
				let $modal = $(Mustache.render(_templates.feedbackModal, data));
				$modal.modal("show");

				setTimeout(function(){						
					$modal.modal("hide");
				}, 2500);
			}
		});		
	}
	function _loadRoutesListFromCluster(selectedCluster){
		console.log("Loading routes for the selected cluster...", selectedCluster);
		ajaxModule.get(['routes', selectedCluster].join("/"), function(data){
			console.log("Routes for the selected cluster: ", data);
			
			if(data.status == "success"){
				_domAssets.routeDropdown.html(Mustache.render(_templates.routesListItems, {"routes": data.routes}));
				_domAssets.routeDropdown.on('change', function(){
					let selectedClusterID = _domAssets.clusterDropDown.val();
					let selectedRouteID = $(this).val();
					_updateRouteUI(selectedClusterID, selectedRouteID);
				});
			}
			else
			{
				let $modal = $(Mustache.render(_templates.feedbackModal, data));
				_domAssets.controlMgmtArea.html('');
				$modal.modal("show");
				setTimeout(function(){						
					$modal.modal("hide");
				}, 2500);
			}

			$("#btn-add-route-to-cluster")
				.off()
				.on("click", function(){
					let selectedClusterID = _domAssets.clusterDropDown.val();
					_addRouteUI(selectedClusterID);
				});
		});
	}
	function _updateRouteUI(clusterID, routeID){
		_domAssets.controlMgmtArea
			.html('')
			.html(Mustache.render(_templates.updateRouteUI, {"cluster": clusterID}));
	}	
	function _addRouteUI(clusterID){
		_domAssets.controlMgmtArea
			.html('')
			.html(Mustache.render(_templates.addRouteUI, {"cluster": clusterID}));

		mapModule.addAutoComplete(_domAssets.controlMgmtArea.find('#ac-origin'),'origin', 'ac-origin-ll');			
		mapModule.addAutoComplete(_domAssets.controlMgmtArea.find('#ac-destination'),'destination', 'ac-destination-ll');

		_domAssets.controlMgmtArea
			.find("#rt-buffer")
			.off()
			.on("change", function(){
				mapModule.directionsChangedAction();
			});

		_domAssets.controlMgmtArea
			.find("#btn-zip-test")
			.off()
			.on("click", function(){
				alert("Tamas");
			});

		_domAssets.controlMgmtArea
			.find("#btn-route-add-confirm")
			.off()
			.on("click", function(e){
				e.preventDefault();

				//Save the route to the DB
				ajaxModule.post(_domAssets.controlMgmtArea.find("#add-route-frm").serializeObject(), 'routes', function(data){
					console.log(data);
					_loadRoutesListFromCluster(data.cluster);
					let $modal = $(Mustache.render(_templates.feedbackModal, data));
					_domAssets.controlMgmtArea.html('');
					$modal.modal("show");
					setTimeout(function(){						
						$modal.modal("hide");
					}, 2500);
				});
			});	
	}
	function _updateAddRouteForm(routeObj){
		_domAssets.controlMgmtArea.find("#zip_wkt").val(routeObj.wkt);
		_domAssets.controlMgmtArea.find("#zip_win_buf").val(routeObj.zip_codes);
		if(routeObj.waypts != ''){
			_domAssets.controlMgmtArea.find("#waypts").val(routeObj.waypts);
		}

	}
  	return {
  		initialize: _init,
  		addClusterUI: _addClusterUI,
  		updateAddRouteForm: _updateAddRouteForm
  	}

})($, window);

let ajaxModule = (function ($, window) {
	let _apiBase = 'http://134.209.217.150:3000/api/';
		
	function _init(){

	}

	function _get(endpoint, callback){
      $.ajax({
        'url': [_apiBase,endpoint].join(''),
        'type': "GET",
        'headers': {'Access-Control-Allow-Origin': '*'},
        'success': callback,
        'dataType': "json"
      }); 		
	}

	function _post(requestData, endpoint, callback){
      console.log('Within ajaxAdmin module\'s _post method...');
      $.ajax({
        'url': [_apiBase,endpoint].join(''),
        'type': 'POST',
        'headers': {'Access-Control-Allow-Origin': '*'},
        'data': requestData,
        'success': callback,
        'dataType': "json"
      }); 		
	}	

	return {
		initialize: _init,
		post: _post,
		get: _get
	};
})($, window);



$(document).on("ready", function(){
	mapModule.initialize();
	controlModule.initialize();

	$("#btn-add-new-cluster").on("click", function(){
		controlModule.addClusterUI();
	});
});