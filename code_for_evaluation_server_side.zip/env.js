module.exports = {
    db: {
      user: 'eagle_gis',
      host: 'localhost',
      database: 'eagle_gis',
      password: '',
      port: 5432,
    }
}
