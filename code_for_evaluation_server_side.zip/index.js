var express 	= require('express');
var http    	= require('http');
var port 	= process.env.PORT || 3000;
var app 	= express();
var bodyParser 	= require('body-parser');
var db          = require('./services/db')

app.use(bodyParser());

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, access-control-allow-origin");
  next();
});

require('./app/routes.js')(app, db);

app.listen(port);

console.log('Application started on port ' + port);

process.on('beforeExit', (code) => {
    // disconnect the PG client;
    console.log('debug :: PG Client disconnect')
    db.disconnect();
});
