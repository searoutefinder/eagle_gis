const express = require('express');
const bodyParser = require('body-parser');

const jsonParser = bodyParser.json()


module.exports = function(app, db) {
	var apiRoutes = express.Router();

	apiRoutes.get('/clusters/:clustername', function(req, res){
		let singleClusterPromise = createIndividualGetClusterPromise(req.params.clustername)
			.then(function(result){
				if(result.rows.length > 0){
					res.json({"status": "success", "msg": "Successful retrieval of cluster", "clusters": result.rows});
				}
				else
				{
					res.json({"status": "warning", "msg": "No clusters available"});
				}				
			})
			.catch(function(error){
				res.json({"status": "error", "msg": "There has been an error during this operation", "trace": error});
			});
	});

	apiRoutes.post('/zipbuffer', function(req, res){
		if(typeof req.body['line'] == 'undefined' || (typeof req.body['line'] != 'undefined' && req.body['line'] == '') ){
			res.json({"error": "No line was specified"});
			return;
		}
		let lines = req.body['line'].split("|");
		let routeNames = (typeof req.body['routenames'] != 'undefined') ?  req.body['routenames'].split("|") : [];
		let truckNum = (typeof req.body['truckid'] != 'undefined') ? req.body['truckid'] : 'NA';
		let clusterName = (typeof req.body['clustername'] != 'undefined') ? req.body['clustername'] : 'NA';
		let bufferSize = (typeof req.body['width'] != 'undefined') ? parseFloat(req.body['width']) : 25;

		let queries = [];

		console.log("Query w attributes: ", truckNum, clusterName, bufferSize);

		for(i=0;i<lines.length;i++){
			queries.push(createBufferPromise(lines[i], bufferSize));
		}			

		Promise.all(queries)
			.then(function(results){
				
				let jsonResponse = {
					"status": "success", 
					"msg": "Successful buffering operation", 
					"cluster": {
						"name": clusterName, 
						"associated_truck": truckNum,
						"routes": []
					}
				};

				for(i=0;i<results.length;i++){
					let zipbag = [];
					for(j=0;j<results[i].zip_codes.length;j++){
						zipbag.push(results[i].zip_codes[j].zip_code);
					}
					jsonResponse.cluster.routes.push({
						"route": results[i].name,
						"line": results[i].coordinates, 
						"zip_codes": zipbag,
						"buffer_miles": results[i].buffer_mi
					});
				}
				res.json(jsonResponse);
			})
			.catch(function(error){
				res.json({"status": "error", "msg": "There has been an error during this operation", "trace": error});
			});					
	});

	apiRoutes.get('/clusters', function(req, res){
		let getPromise = createGetClusterPromise();
		getPromise
			.then(function(result){
				if(result.rows.length > 0){
					res.json({"status": "success", "msg": "Successful retrieval of clusters", "clusters": result.rows});
				}
				else
				{
					res.json({"status": "warning", "msg": "No clusters available"});
				}
			})
			.catch(function(error){
				res.json({"status": "error", "msg": "There has been an error during this operation", "trace": error});
			});
	});

	apiRoutes.post('/clusters', function(req, res){
		let insertPromise = createInsertClusterPromise({'name': req.body.clustername, 'truckid': req.body.truckid});
		insertPromise
			.then(function(result){
				if(result.command == "INSERT" && result.rowCount == 1){
					res.json({"status": "success", "msg": "A new cluster has been added successfully"});
				}			
			})
			.catch(function(error){
				res.json({"status": "error", "msg": "There has been an error during this operation", "trace": error});
			});
	});	

	apiRoutes.get('/routes/:cluster', function(req, res){
		let routesCluster = createRoutesFromClusterPromise(req.params.cluster)
			.then(function(result){
				if(result.rows.length > 0){
					res.json({"status": "success", "msg": "Successful retrieval of routes contained within the selected cluster", "cluster": result.cluster, "routes": result.rows});
				}
				else
				{
					res.json({"status": "warning", "msg": "No routes available within the selected cluster"});
				}				
			})
			.catch(function(error){
				console.log(error);
				res.json({"status": "error", "msg": "There has been an error during this operation", "trace": error});
			});
	});	

	apiRoutes.post('/routes', function(req, res){
		let routeInsertPromise = createInsertRoutePromise(req.body);
		routeInsertPromise
			.then(function(result){
				if(result.command == "INSERT" && result.rowCount == 1){
					res.json({"status": "success", "msg": "A new route has been successfully added to the selected cluster", "cluster": result.fromCluster});
				}
			})
			.catch(function(error){
				res.json({"status": "error", "msg": "There has been an error during this operation", "trace": error});
			});
	});

	apiRoutes.get('/routes/:id', function(req, res){
		let routeID = req.params.id;
		let routePromise = routeDataPromise(routeID);
		routePromise
			.then(function(result){
				if(result.rows.length > 0){
					res.json({"status": "success", "msg": "Successful retrieval of details for the selected route", "routes": result.rows});
				}
				else
				{
					res.json({"status": "warning", "msg": "No route matching the provided ID is available"});
				}
			})
			.catch(function(error){
				res.json({"status": "error", "msg": "There has been an error during this operation", "trace": error});
			});
	});

	function milesToM(miles){
		return parseFloat(miles * 1609.344);
	}
	function routeDataPromise(routeID){
		return new Promise(function(resolve, reject){
			db.query("SELECT * FROM routes WHERE id=$1", [parseInt(routeID)], function(err, result){
				if(err){
					reject(err);
					return;
				}
				resolve(result);
			});		
		});	
	}
	function createRoutesFromClusterPromise(clusterID){
		return new Promise(function(resolve, reject){
			db.query("SELECT * FROM routes WHERE cluster=$1", [parseInt(clusterID)], function(err, result){
				if(err){
					reject(err);
					return;
				}
				result["cluster"] = clusterID;
				resolve(result);
			});		
		});		
	}
	function createIndividualGetClusterPromise(clusterID){
		return new Promise(function(resolve, reject){
			db.query("SELECT * FROM clusters WHERE id=$1", [clusterID], function(err, result){
				if(err){
					reject(err);
					return;
				}
				resolve(result);
			});		
		});		
	}
	function createGetClusterPromise(){
		return new Promise(function(resolve, reject){
			db.query("SELECT * FROM clusters", [], function(err, result){
				if(err){
					reject(err);
					return;
				}
				resolve(result);
			});		
		});		
	}
	function createInsertClusterPromise(clusterData){
		return new Promise(function(resolve, reject){
			db.query("INSERT INTO clusters (name, truck_id) VALUES ($1, $2)", 
				[clusterData.name, clusterData.truckid], function(err, result){
				if(err){
					console.log(err);
					reject(err);
					return;
				}
				resolve(result);
			});		
		});		
	}
	function createInsertRoutePromise(routeData){
		return new Promise(function(resolve, reject){
			db.query("INSERT INTO routes (name, origin, origin_geom, destination, destination_geom, buffer_size, route_line_geom, cluster,zip_codes_within_buffer) \
				VALUES ($1, $2, ST_SetSRID(ST_MakePoint($3, $4),4326), $5, ST_SetSRID(ST_MakePoint($6, $7),4326), $8, ST_GeomFromText($9,4326), $10, $11)", 
				[
					routeData['rt-name'],
					routeData['ac-origin'],
					parseFloat(routeData['ac-origin-ll'].split(",")[0]),
					parseFloat(routeData['ac-origin-ll'].split(",")[1]),
					routeData['ac-destination'],
					parseFloat(routeData['ac-destination-ll'].split(",")[0]),
					parseFloat(routeData['ac-destination-ll'].split(",")[1]),
					parseFloat(routeData['rt-buffer']),
					routeData['zip_wkt'],
					parseInt(routeData['cluster']),
					routeData['zip_win_buf']	

				], function(err, result){
				if(err){
					console.log(err);
					reject(err);
					return;
				}
				result["fromCluster"] = parseInt(routeData['cluster']);
				console.log(result);
				resolve(result);
			});		
		});		
	}	
	function createBufferPromise(coordinates, bufferwidth){
		return new Promise(function(resolve, reject){
			db.query("SELECT zip_code FROM zip_codes WHERE ST_Intersects(zip_codes.geom, ST_Buffer(ST_GeomFromText('"+ coordinates + "',4326)::geography, " + milesToM(bufferwidth) + ")::geometry);", 
				[], function(err, result){
				if(err){
					console.log(err);
					reject(err);
					return;
				}
				resolve({"coordinates": coordinates, "zip_codes": result.rows, "buffer_mi": bufferwidth});
			});		
		});
	}

	app.use('/api', apiRoutes);

};
